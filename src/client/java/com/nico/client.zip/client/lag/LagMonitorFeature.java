package com.nico.client.lag;

import com.nico.client.configuration.NsmConfig;
import com.nico.client.configuration.NsmConfigManager;
import com.nico.client.configuration.category.CategoryDungeons;
import com.nico.client.configuration.category.CategoryOther;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

import java.util.function.Supplier;

public class LagMonitorFeature {
    private static boolean initialized;

    private static final LagMonitorConfig config = LagMonitorConfig.load();

    private LagMonitorFeature() { }

    public static synchronized void initialize() {
        if (initialized) return;

        syncConfig();

        LagMonitorService service = LagMonitorService.getInstance();
        service.configure(config);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            syncConfig();
            service.tick(client);
        });

        ClientPlayConnectionEvents.JOIN.register(
                (handler, sender, client) -> service.onJoin(client)
        );

        ClientPlayConnectionEvents.DISCONNECT.register(
                (handler, client) -> service.onDisconnect()
        );

        LagMonitorHud.register();

        initialized = true;
        System.out.println("[NSM Lag] Lag monitor initialized");
    }

    private static void syncConfig() {
        NsmConfig current = NsmConfigManager.getConfig();
        CategoryOther.LagMonitor settings = current != null && current.other != null
                ? current.other.lagMonitor
                : null;

        config.applyMoulConfig(settings);
        config.sanitize();
    }

    public static LagMonitorConfig config() {
        return config;
    }

    public static void saveConfig() {
        config.save();
    }

    public static void openLastSummary(Screen parent) {
        Minecraft client = Minecraft.getInstance();
        client.setScreen(new LagSummaryScreen(
                parent,
                LagMonitorService.getInstance().lastSummary()
        ));
    }
}
