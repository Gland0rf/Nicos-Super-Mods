package com.nico.client.dungeon

import com.nico.client.secretTimer.SecretRoomTimerClient
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents
import net.fabricmc.fabric.api.event.player.AttackEntityCallback
import net.fabricmc.fabric.api.event.player.UseBlockCallback
import net.minecraft.client.Minecraft
import net.minecraft.core.BlockPos
import net.minecraft.network.protocol.Packet
import net.minecraft.network.protocol.game.ClientboundDamageEventPacket
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket
import net.minecraft.network.protocol.game.ClientboundTakeItemEntityPacket
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.ambient.Bat
import net.minecraft.world.entity.item.ItemEntity
import net.minecraft.world.entity.player.Player
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.SkullBlock
import net.minecraft.world.phys.Vec3

object SecretDispatcher {
    private var initialized = false
    private var lastGameMessage = ""
    private var lastGameMessageOverlay = false
    private var lastGameMessageAtNanos = 0L

    private val minecraftFormattingRegex = Regex("§[0-9A-FK-OR]", RegexOption.IGNORE_CASE)

    private val dungeonItemDrops = listOf(
        "Health Potion VIII Splash Potion",
        "Healing Potion 8 Splash Potion",
        "Healing Potion VIII Splash Potion",
        "Healing VIII Splash Potion",
        "Healing 8 Splash Potion",
        "Decoy",
        "Inflatable Jerry",
        "Spirit Leap",
        "Trap",
        "Training Weights",
        "Defuse Kit",
        "Dungeon Chest Key",
        "Treasure Talisman",
        "Revive Stone",
        "Architect's First Draft",
        "Secret Dye",
        "Candycomb"
    )

    private val secretCounterRegexes = listOf(
        Regex("""(\d+)\s*/\s*(\d+)\s+Secrets?""", RegexOption.IGNORE_CASE),
        Regex("""Secrets?\s*:?\s*(\d+)\s*/\s*(\d+)""", RegexOption.IGNORE_CASE)
    )

    @JvmStatic
    fun init() {
        if (initialized) return

        ClientReceiveMessageEvents.ALLOW_GAME.register { message, overlay ->
            handleGameMessage(message.string, overlay)
            true
        }

        UseBlockCallback.EVENT.register { player, level, hand, hitResult ->
            handleBlockUse(player, level, hand, hitResult.blockPos)
            InteractionResult.PASS
        }

        AttackEntityCallback.EVENT.register { _, _, hand, entity, _ ->
            if (hand != InteractionHand.OFF_HAND && entity is Bat && isDungeonClearContext()) {
                BatSecretTracker.onSelfAttack(entity)
            }
            InteractionResult.PASS
        }

        ClientEntityEvents.ENTITY_UNLOAD.register { entity, _ ->
            when (entity) {
                is ItemEntity -> handlePotentialItemUnload(entity)
                is Bat -> if (isDungeonClearContext()) {
                    BatSecretTracker.onEntityUnload(entity)
                }
            }
        }

        initialized = true
        println("[NSM] SecretDispatcher Fabric compatibility hooks registered")
    }

    @JvmStatic
    fun onReceive(packet: Packet<*>) {
        try {
            when (packet) {
                is ClientboundTakeItemEntityPacket ->
                    handleTakeItem(packet)

                is ClientboundDamageEventPacket ->
                    if (isDungeonClearContext()) BatSecretTracker.onDamageEvent(packet)

                is ClientboundSystemChatPacket ->
                    handleSystemChat(packet)

                is ClientboundSetActionBarTextPacket ->
                    handleActionBar(packet)
            }
        } catch (throwable: Throwable) {
            System.err.println("[NSM] SecretDispatcher failed while handling ${packet.javaClass.simpleName}: ${throwable.message}")
            throwable.printStackTrace()
        }
    }

    @JvmStatic
    fun onSend(packet: Packet<*>) {
        if (packet is ServerboundUseItemOnPacket) {
            handleUseItemOn(packet)
        }
    }

    private fun handleTakeItem(packet: ClientboundTakeItemEntityPacket) {
        if (!isDungeonClearContext()) return


        val client = Minecraft.getInstance()
        val player = client.player ?: return
        if (packet.playerId != player.id) return
        val entity = client.level?.getEntity(packet.itemId) as? ItemEntity ?: return

        if (!isDungeonItemDrop(entity.item.hoverName.string)) return
        if (entity.distanceTo(player) > 8) return

        dispatchItemSecret(entity.blockPosition())
    }

    @JvmStatic
    fun clearTransientState() {
        BatSecretTracker.clear()
        lastGameMessage = ""
        lastGameMessageOverlay = false
        lastGameMessageAtNanos = 0L
    }

    private fun handleUseItemOn(packet: ServerboundUseItemOnPacket) {
        val client = Minecraft.getInstance()
        val player = client.player ?: return
        val level = client.level ?: return
        handleBlockUse(player, level, packet.hand, packet.hitResult.blockPos)
    }

    private fun handleBlockUse(player: Player, level: Level, hand: InteractionHand, pos: BlockPos) {
        if (!isDungeonClearContext()) return
        if (hand == InteractionHand.OFF_HAND) return

        val blockState = level.getBlockState(pos)

        if (blockState.block is SkullBlock) {
            val target = Vec3(
                pos.x.toDouble(),
                pos.y.toDouble(),
                pos.z.toDouble()
            )

            if (player.eyePosition.distanceToSqr(target) > 20.25) return
        }

        if (!DungeonSecretClassifier.isSecret(level, blockState, pos)) return

        when {
            blockState.`is`(Blocks.CHEST) || blockState.`is`(Blocks.TRAPPED_CHEST) ->
                dispatchChestSecret(pos)

            blockState.block is SkullBlock ->
                dispatchPotentialBlockSecret(pos)
            else ->
                dispatchSecret(pos)
        }
    }

    private fun handleSystemChat(packet: ClientboundSystemChatPacket) {
        handleGameMessage(packet.content.string, packet.overlay())
    }

    private fun handleActionBar(packet: ClientboundSetActionBarTextPacket) {
        handleGameMessage(packet.text.string, true)
    }

    private fun handleGameMessage(raw: String, overlay: Boolean) {
        val clean = cleanText(raw)
        val now = System.nanoTime()

        // The same message can arrive through both the vanilla packet fallback and the
        // Fabric event path on a normal Fabric client.
        if (clean == lastGameMessage
            && overlay == lastGameMessageOverlay
            && now - lastGameMessageAtNanos < 100_000_000L) {
            return
        }

        lastGameMessage = clean
        lastGameMessageOverlay = overlay
        lastGameMessageAtNanos = now

        if (handleSecretCounter(clean)) return
        if (overlay) return

        BatSecretTracker.onCombatMessage(clean)

        if (clean.contains("That chest is locked!")) {
            SecretRoomTimerClient.onLockedChestMessage()
        }

        SecretRoomTimerClient.onChatMessage(clean)
    }

    private fun handleSecretCounter(text: String): Boolean {
        val match = secretCounterRegexes.firstNotNullOfOrNull { it.find(text) } ?: return false
        val found = match.groupValues[1].toIntOrNull() ?: return false
        val total = match.groupValues[2].toIntOrNull() ?: return false

        SecretRoomTimerClient.onRoomSecretsPacket(found, total)
        return true
    }

    private fun cleanText(text: String): String =
        text.replace(minecraftFormattingRegex, "").trim()

    private fun handlePotentialItemUnload(entity: ItemEntity) {
        if (!isDungeonClearContext()) return

        val client = Minecraft.getInstance()
        val player = client.player ?: return
        val level = client.level ?: return

        if (!isDungeonItemDrop(entity.item.hoverName.string)) return

        val selfDistance = entity.distanceTo(player)
        if (selfDistance > 3.0) return

        for (other in level.players()) {
            if (other === player) continue
            if (entity.distanceTo(other) + 0.25 < selfDistance) return
        }

        SecretRoomTimerClient.onPotentialItemSecretPickup(entity.blockPosition())
    }

    private fun isDungeonClearContext(): Boolean {
        val client = Minecraft.getInstance()
        val player = client.player ?: return false
        if (client.level == null) return false

        if (DungeonState.inClear) return true

        // Fallback for clients whose tab/scoreboard rendering changes prevent
        // LocationUtils from being updated by packet mixins.
        return try {
            DungeonScanner.isInDungeon(player)
        } catch (_: Throwable) {
            false
        }
    }

    private fun dispatchSecret(pos: BlockPos) {
        SecretRoomTimerClient.onSecretPickup(pos)
    }

    private fun dispatchItemSecret(pos: BlockPos) {
        SecretRoomTimerClient.onItemSecretPickup(pos)
    }

    private fun dispatchPotentialBlockSecret(pos: BlockPos) {
        SecretRoomTimerClient.onPotentialBlockSecretPickup(pos)
    }

    private fun dispatchChestSecret(pos: BlockPos) {
        SecretRoomTimerClient.onChestSecretPickup(pos)
    }

    private fun isDungeonItemDrop(name: String): Boolean =
        dungeonItemDrops.any { name.contains(it, ignoreCase = true) }
}