package com.nico.client.wiki.service;

import com.google.gson.JsonObject;
import com.nico.client.wiki.*;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Shared parsing and HTTP helpers used by the wiki service pipeline.
 *
 * <p>Parser subclasses inherit these utilities so URL normalization, rich-text extraction,
 * ignored-element handling, and MediaWiki API requests follow the same rules throughout the scraper.</p>
 */
public class WikiServiceSupport {
    protected static final String WIKI_API_ENDPOINT = "https://hypixelskyblock.minecraft.wiki/api.php";
    protected static final String WIKI_BASE = "https://hypixelskyblock.minecraft.wiki";
    protected static final String WIKI_ARTICLE_BASE = WIKI_BASE + "/w/";
    protected static final boolean DEBUG = Boolean.getBoolean("nsm.wiki.debug");

    protected static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    protected static String normalizeImageUrl(Element image, String value) {
        if (value == null || value.isBlank() || value.startsWith("data:")) {
            return "";
        }

        String result = value.trim();
        try {
            URI base = URI.create(image.baseUri().isBlank() ? WIKI_BASE + "/" : image.baseUri());
            result = base.resolve(result).toString();
        } catch (IllegalArgumentException ignored) {
            result = absoluteUrl(result);
        }
        return result.replace(" ", "%20");
    }

    protected static String inlineImagePlaceholder(WikiImage image) {
        // Keep every inline icon in the same three-space text slot. The
        // renderer adds a one-pixel gutter on both sides of the actual image,
        // so the icon cannot touch the previous/next glyph and the spacing
        // stays consistent regardless of the source image dimensions.
        return "\u00A0\u00A0\u00A0";
    }

    protected static WikiText parseStyledText(Element element) {
        Element clone = element.clone();
        removeIgnoredElements(clone);
        List<MutableSpan> spans = new ArrayList<>();
        appendNodeText(clone, spans, "", false, false, "", "", "");
        trimSpans(spans);
        List<WikiText.Span> result = new ArrayList<>();
        for (MutableSpan span : spans) {
            if (!span.text.isEmpty()) {
                result.add(new WikiText.Span(
                        span.text,
                        span.href,
                        span.bold,
                        span.italic,
                        span.cssClasses,
                        span.hoverTitle,
                        span.hoverText,
                        span.inlineImage
                ));
            }
        }
        return new WikiText(result);
    }

    protected static void appendNodeText(
            Node node,
            List<MutableSpan> spans,
            String href,
            boolean bold,
            boolean italic,
            String cssClasses,
            String hoverTitle,
            String hoverText
    ) {
        if (node instanceof TextNode textNode) {
            appendText(spans, textNode.getWholeText(), href, bold, italic, cssClasses, hoverTitle, hoverText);
            return;
        }
        if (!(node instanceof Element element)) {
            return;
        }
        String tag = element.tagName();

        if (element.hasClass(WikiHtmlContract.INVENTORY_SLOT)
                && WikiContentParser.isInlineInventorySlot(element)) {
            WikiItemSlot slot = WikiContentParser.parseItemSlot(element);
            WikiItemSlot.Frame frame = slot.activeFrame();
            if (!frame.image().isEmpty()) {
                spans.add(new MutableSpan(
                        inlineImagePlaceholder(frame.image()),
                        firstNonBlank(frame.link(), href),
                        bold,
                        italic,
                        cssClasses,
                        firstNonBlank(frame.tooltipTitle(), frame.displayName(), hoverText),
                        firstNonBlank(frame.tooltipText(), hoverText),
                        frame.image()
                ));
            }
            return;
        }

        if (tag.equals("script") || tag.equals("style") || tag.equals("noscript")
                || tag.equals("svg") || tag.equals("canvas")) {
            return;
        }
        if (tag.equals("img")) {
            WikiImage image = WikiContentParser.parseImage(element);
            if (!image.isEmpty() && WikiContentParser.isInlineWikiIcon(element, image)) {
                String imageHoverTitle = firstNonBlank(
                        hoverTitle,
                        normalizePlainHoverAttribute(element.attr("title")),
                        normalizePlainHoverAttribute(element.attr("alt"))
                );

                spans.add(new MutableSpan(
                        inlineImagePlaceholder(image),
                        href,
                        bold,
                        italic,
                        cssClasses,
                        imageHoverTitle,
                        hoverText,
                        image
                ));
            }
            return;
        }

        if (tag.equals("br")) {
            appendText(spans, "\n", href, bold, italic, cssClasses, hoverTitle, hoverText);
            return;
        }

        String nextHref = tag.equals("a") ? absoluteUrl(element, "href") : href;
        boolean nextBold = bold || tag.equals("b") || tag.equals("strong");
        boolean nextItalic = italic || tag.equals("i") || tag.equals("em");
        String nextClasses = mergeClassStrings(cssClasses, String.join(" ", element.classNames()));

        String mineTipTitle = normalizeMineTipAttribute(element.attr("data-minetip-title"));
        String mineTipText = normalizeMineTipAttribute(element.attr("data-minetip-text"));
        String browserTitle = normalizePlainHoverAttribute(element.attr("title"));
        String nextHoverTitle = firstNonBlank(mineTipTitle, hoverTitle);
        String nextHoverText = firstNonBlank(mineTipText, browserTitle, hoverText);

        for (Node child : element.childNodes()) {
            appendNodeText(
                    child,
                    spans,
                    nextHref,
                    nextBold,
                    nextItalic,
                    nextClasses,
                    nextHoverTitle,
                    nextHoverText
            );
        }
        if (tag.equals("p") || tag.equals("li") || tag.equals("dd") || tag.equals("dt") || tag.equals("div")) {
            appendText(spans, " ", href, bold, italic, cssClasses, hoverTitle, hoverText);
        }
    }

    protected static void appendText(
            List<MutableSpan> spans,
            String raw,
            String href,
            boolean bold,
            boolean italic,
            String cssClasses,
            String hoverTitle,
            String hoverText
    ) {
        if (raw == null || raw.isEmpty()) {
            return;
        }
        String text = raw.replace('\u00a0', ' ')
                .replaceAll("[\\t\\x0B\\f\\r ]+", " ")
                .replaceAll(" *\\n *", "\n");

        if (spans.isEmpty()) {
            text = text.stripLeading();
        } else {
            MutableSpan previous = spans.get(spans.size() - 1);
            if (!previous.inlineImage.isEmpty() && text.startsWith(" ")) {
                // The inline-image placeholder already provides the visual gap.
                // Removing this normal space also prevents a wrap opportunity
                // between the icon and its label.
                text = text.substring(1);
            } else if (previous.text.endsWith(" ") && text.startsWith(" ")
                    || (previous.text.endsWith("\n") && text.startsWith(" "))
                    || (previous.text.endsWith(" ") && text.startsWith("\n"))) {
                text = text.substring(1);
            }
        }
        if (text.isEmpty()) {
            return;
        }
        if (!spans.isEmpty()) {
            MutableSpan previous = spans.get(spans.size() - 1);
            if (previous.inlineImage.isEmpty()
                    && previous.sameFormat(href, bold, italic, cssClasses, hoverTitle, hoverText)) {
                previous.text += text;
                return;
            }
        }
        spans.add(new MutableSpan(text, href, bold, italic, cssClasses, hoverTitle, hoverText, WikiImage.empty()));
    }

    protected static String normalizeMineTipAttribute(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }
        String escapedSlash = "\u0000NSM_WIKI_SLASH\u0000";
        return org.jsoup.parser.Parser.unescapeEntities(value, false)
                .replace("<br />", "\n")
                .replace("<br/>", "\n")
                .replace("<br>", "\n")
                .replace("\\n", "\n")
                .replace("\\/", escapedSlash)
                .replace("//", "\n\n")
                .replace("/", "\n")
                .replace(escapedSlash, "/")
                .replaceAll("[\\t\\x0B\\f\\r ]+", " ")
                .replaceAll(" *\\n *", "\n")
                .trim();
    }

    protected static String normalizePlainHoverAttribute(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }
        return org.jsoup.parser.Parser.unescapeEntities(value, false)
                .replaceAll("\\s+", " ")
                .trim();
    }

    protected static void trimSpans(List<MutableSpan> spans) {
        while (!spans.isEmpty() && spans.get(0).text.isBlank() && spans.get(0).inlineImage.isEmpty()) {
            spans.remove(0);
        }
        while (!spans.isEmpty()
                && spans.get(spans.size() - 1).text.isBlank()
                && spans.get(spans.size() - 1).inlineImage.isEmpty()) {
            spans.remove(spans.size() - 1);
        }
        if (!spans.isEmpty()) {
            if (spans.get(0).inlineImage.isEmpty()) {
                spans.get(0).text = spans.get(0).text.stripLeading();
            }
            if (spans.get(spans.size() - 1).inlineImage.isEmpty()) {
                spans.get(spans.size() - 1).text = spans.get(spans.size() - 1).text.stripTrailing();
            }
        }
    }

    protected static boolean isEmptyBlock(WikiBlock block) {
        if (block instanceof WikiBlock.Heading heading) {
            return heading.text().isBlank();
        }
        if (block instanceof WikiBlock.MessageBox messageBox) {
            return messageBox.content().isEmpty();
        }
        if (block instanceof WikiBlock.Paragraph paragraph) {
            return paragraph.content().isEmpty();
        }
        if (block instanceof WikiBlock.ListItem item) {
            return item.content().isEmpty();
        }
        if (block instanceof WikiBlock.ForgingTree forgingTree) {
            return forgingTree.tree().isEmpty();
        }
        if (block instanceof WikiBlock.Table table) {
            return table.rows().isEmpty();
        }
        if (block instanceof WikiBlock.TabGroup tabs) {
            return tabs.tabs().isEmpty();
        }
        if (block instanceof WikiBlock.Crafting crafting) {
            return crafting.grid().isEmpty();
        }
        if (block instanceof WikiBlock.Image image) {
            return image.image().isEmpty();
        }
        return false;
    }

    protected static void removeIgnoredElements(Element root) {
        root.select("script,style,noscript").remove();

        for (Element element : new ArrayList<>(root.select("[hidden]"))) {
            if (!element.hasClass(WikiHtmlContract.UI_TAB_CONTENT)) element.remove();
        }

        root.select(".sortkey,.sort-key,.mw-sortkey,.mw-sort-key").remove();

        for (Element element : new ArrayList<>(root.select("[style]"))) {
            String style = element.attr("style")
                    .toLowerCase(java.util.Locale.ROOT)
                    .replaceAll("\\s+", "");

            if ((style.contains("display:none") || style.contains("visibility:hidden"))
                    && !element.hasClass(WikiHtmlContract.UI_TAB_CONTENT)) {
                element.remove();
            }
        }

        root.getElementsByClass(WikiHtmlContract.EDIT_SECTION).remove();
        root.getElementsByClass(WikiHtmlContract.REFERENCE).remove();
        root.getElementsByClass(WikiHtmlContract.REFERENCES).remove();
        root.getElementsByClass(WikiHtmlContract.PRINT_FOOTER).remove();
        root.getElementsByClass(WikiHtmlContract.CATEGORY_LINKS).remove();
        root.getElementsByClass(WikiHtmlContract.NAVBOX).remove();

        Element tocById = root.getElementById("toc");
        if (tocById != null) {
            tocById.remove();
        }
        root.getElementsByClass("toc").remove();
        root.getElementsByClass("mw-table-of-contents").remove();
    }

    protected static boolean isIgnoredElement(Element element) {
        return element.hasClass(WikiHtmlContract.EDIT_SECTION)
                || element.hasClass(WikiHtmlContract.REFERENCE)
                || element.hasClass(WikiHtmlContract.REFERENCES)
                || element.hasClass(WikiHtmlContract.PRINT_FOOTER)
                || element.hasClass(WikiHtmlContract.CATEGORY_LINKS)
                || element.hasClass(WikiHtmlContract.NAVBOX)
                || element.hasClass(WikiHtmlContract.NO_EXCERPT)
                || element.hasClass(WikiHtmlContract.NOT_SEARCHABLE)
                || element.id().equals("toc")
                || element.hasClass("toc")
                || element.hasClass("mw-table-of-contents");
    }

    protected static Element directChildWithClass(Element parent, String className) {
        if (parent == null) {
            return null;
        }
        for (Element child : parent.children()) {
            if (child.hasClass(className)) {
                return child;
            }
        }
        return null;
    }

    protected static List<Element> directChildrenWithClass(Element parent, String className) {
        List<Element> result = new ArrayList<>();
        if (parent == null) {
            return result;
        }
        for (Element child : parent.children()) {
            if (child.hasClass(className)) {
                result.add(child);
            }
        }
        return result;
    }

    protected static Element ownedDescendantWithClass(
            Element owner,
            String targetClass,
            String ownerClass
    ) {
        if (owner == null) {
            return null;
        }
        for (Element candidate : owner.getElementsByClass(targetClass)) {
            Element nearestOwner = nearestAncestorWithClass(candidate, ownerClass);
            if (nearestOwner == owner) {
                return candidate;
            }
        }
        return null;
    }

    protected static boolean isInsideWidget(Element element) {
        return hasAncestorClass(element, WikiHtmlContract.INVENTORY_SLOT)
                || hasAncestorClass(element, WikiHtmlContract.CRAFTING_TABLE)
                || hasAncestorClass(element, WikiHtmlContract.CRAFTING_ROOT);
    }

    protected static boolean hasAncestorClass(Element element, String className) {
        return nearestAncestorWithClass(element, className) != null;
    }

    protected static Element nearestAncestorWithClass(Element element, String className) {
        Element current = element.parent();
        while (current != null) {
            if (current.hasClass(className)) {
                return current;
            }
            current = current.parent();
        }
        return null;
    }

    protected static String absoluteUrl(Element element, String attribute) {
        String absolute = element.absUrl(attribute);
        return absolute.isBlank() ? absoluteUrl(element.attr(attribute)) : absolute;
    }

    protected static String absoluteUrl(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }
        String result = value.trim();
        if (result.startsWith("//")) {
            return "https:" + result;
        }
        if (result.startsWith("/")) {
            return WIKI_BASE + result;
        }
        return result;
    }

    protected static String mergeClassStrings(String left, String right) {
        if (left == null || left.isBlank()) {
            return right == null ? "" : right.trim();
        }
        if (right == null || right.isBlank()) {
            return left.trim();
        }
        return left.trim() + " " + right.trim();
    }

    protected static int parsePositiveInt(String value, int fallback) {
        try {
            return Math.max(0, Integer.parseInt(value.trim()));
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    protected static String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value.trim();
            }
        }
        return "";
    }

    protected static String jsonString(JsonObject object, String name) {
        try {
            return object != null && object.has(name) && !object.get(name).isJsonNull()
                    ? object.get(name).getAsString()
                    : "";
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    protected static HttpRequest.Builder requestBuilder(URI uri) {
        return WikiHttp.request(uri, Duration.ofSeconds(25));
    }

    protected static String validateResponse(HttpResponse<String> response) {
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new HypixelWikiService.WikiRequestException("Wiki HTTP " + response.statusCode() + " from " + response.uri());
        }
        if (response.body() == null || response.body().isBlank()) {
            throw new HypixelWikiService.WikiRequestException("Wiki returned an empty response");
        }
        return response.body();
    }

    protected static URI buildApiUri(Map<String, String> parameters) {
        return WikiHttp.buildQueryUri(WIKI_API_ENDPOINT, parameters);
    }

    protected static void logContractElements(Element root) {
        System.out.println("[NSM Wiki] article root classes=" + root.classNames());
        for (String className : List.of(
                WikiHtmlContract.INFOBOX,
                WikiHtmlContract.CRAFTING_TABLE,
                WikiHtmlContract.TABBER,
                WikiHtmlContract.WIKITABLE,
                WikiHtmlContract.INVENTORY_SLOT
        )) {
            System.out.println("[NSM Wiki] ." + className + " count=" + root.getElementsByClass(className).size());
        }
    }

    protected static final class MutableSpan {
        private String text;
        private final String href;
        private final boolean bold;
        private final boolean italic;
        private final String cssClasses;
        private final String hoverTitle;
        private final String hoverText;
        private final WikiImage inlineImage;

        private MutableSpan(
                String text,
                String href,
                boolean bold,
                boolean italic,
                String cssClasses,
                String hoverTitle,
                String hoverText,
                WikiImage inlineImage
        ) {
            this.text = text;
            this.href = href == null ? "" : href;
            this.bold = bold;
            this.italic = italic;
            this.cssClasses = cssClasses == null ? "" : cssClasses;
            this.hoverTitle = hoverTitle == null ? "" : hoverTitle;
            this.hoverText = hoverText == null ? "" : hoverText;
            this.inlineImage = inlineImage == null ? WikiImage.empty() : inlineImage;
        }

        private boolean sameFormat(
                String otherHref,
                boolean otherBold,
                boolean otherItalic,
                String otherClasses,
                String otherHoverTitle,
                String otherHoverText
        ) {
            return href.equals(otherHref == null ? "" : otherHref)
                    && bold == otherBold
                    && italic == otherItalic
                    && cssClasses.equals(otherClasses == null ? "" : otherClasses)
                    && hoverTitle.equals(otherHoverTitle == null ? "" : otherHoverTitle)
                    && hoverText.equals(otherHoverText == null ? "" : otherHoverText);
        }
    }
}
